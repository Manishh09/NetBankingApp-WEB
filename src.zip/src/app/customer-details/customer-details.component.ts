import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.scss']
})
export class CustomerDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
