export interface CustomerData{
    emailId:any,
    password:any,
    
}