export class NotificationModel{

        NotificationUid : string;
        NotificationId :number;
        CustomerUid : string;
        Message : string;
        Createdby : string;
        CreatedOn : Date;
       
    
}